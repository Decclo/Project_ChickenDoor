﻿/*
 * Project Chicken Door
 * Author:		Hans V. Rasmussen
 * Created:		30/03-2017 18:42
 * Modified:	04/05-2017 21:45
 * Version:		0.7
*/

/*
Current Status:
	
	Note: Interrupt and sleep do not work together, find a solution.
	
	Completed:
	- DS3231 Timer Module implemented.
	- Timer implemented, don't forget to put counter max value to 60.
	- Interrupt working.
	- User interfacing implemented.
	- Implemented sleep mode.
	
	To Do:
	- Cleaning up user interfacing and DS3231_ExtraFunc.
	- Implementing motor control.
	- (HARDWARE) Making amplifier for controlling motor.
*/


//	------------	DEFINES & INCLUDES	---------------	//
#define F_CPU 16000000UL		// Clock speed of micro processor.

#include <Arduino.h>			// Arduino Core
#include <MD_DS3231.h>			// DS3231 library
#include <Wire.h>				// Arduino library for I2C communication

#include <stdio.h>
#include <avr/io.h>
//#include <util/delay.h>		// Includes functions for delay.
#include <avr/interrupt.h>		// Includes functions for the interrupts, sei() to enable and cli() to disable
#include "DS3231_ExtraFunc.h"	// MD_DS3231_Test sketch converted into a library and slightly changed
#include "sleep.h"				// Arduino Library for sleep


/* Function Prototypes:

outputType functionName(inputType, inputType);

*/

class supportFunctions
{
public:
	/*
	@ Constructor without arguments.
	
	@ Input:	Void
	@ Output:	Void
	*/
	supportFunctions(void){}
	
	/*
	@ Starts the userInterface, returns once the user exits.
	
	@ Input:	Void
	@ Output:	Void
	*/
	void userInterface(void);
	
	/*
	@ Prints the help dialogue for the simple userInterface.
	
	@ Input:	Void
	@ Output:	Void
	*/
	void helpMessage(void);
	
	
	
	/*
	@ Function to operate the motor
	
	@ Input:	Void
	@ Output:	Void
	*/
	void motorControl(void);
	
	/*
	@ Puts microcontroller to sleep.
	
	@ Input:	Void
	@ Output:	Void
	*/
	void sleepProcedure(void);
	
protected:
private:
};


//	------------	GLOBAL VARIABLES	------------------	//
supportFunctions SF;

//Interrupt variables have to be global, and are to be defined as follows: Volatile varType var_name;
	// Timer1 & sleep mode
volatile uint8_t timer1_counter = 0;
volatile boolean sleepStatus = false;
volatile boolean motorNext = false;


void setup(void)
{
	//	----------------	SETUP	-----------------------	//
	
	// Setting up serial communication, and doing obligatory fancy effects.
	Serial.begin(9600);
	
	DDRD &= ~(1 << DDD2);     // Clear the PD2 pin
	// PD2 (PCINT0 pin) is now an input
	
	//PORTD |= (1 << PORTD2);    // turn On the Pull-up
	// PD2 is now an input with pull-up enabled
	
	//	---------------	LOCAL VARIABLES	-------------------	//
	char char_read;
	

	//	-----------	TIMER & INTERRUPTS SETUP	-----------	//
	cli();	// make sure that all interrupts are offline while setting them up
	
	EICRA |= (1 << ISC00) | (1 << ISC01);	// set INT0 to trigger	on rising edge
	EIMSK |= (1 << INT0);					// turn on INT0


	// initialize timer1
	TCCR1A = 0;
	TCCR1B = 0;
	
	OCR1A = 0x3D08;			// compare match register
	TCCR1B |= (1 << CS10)|(1 << CS12)|(1 << WGM12);    // 1024 prescaler
	TIMSK1 |= (1 << OCIE1A);// enable timer compare interrupt
	sei();			// enable all interrupts
	/*
	To start the timer do:
	TCCR1A = 0;
	TCCR1B = 0;
	TCNT1  = 0;
	
	To stop the timer do:
	TCCR1B |= (1 << CS10)|(1 << CS12)|(1 << WGM12);
	TCNT1  = 0;
	*/
	
	Serial.println("System online, the system will enter standby in 60 seconds unless interrupted");
	Serial.println("Send any command to engage Debugging Mode.");
	Serial.println();
	Serial.println();
	
	
	//	------------	MAIN LOOP	-----------------------	//
	
	
	while (1)
	{
		RTC.checkAlarm1();
		RTC.checkAlarm2();

		if (Serial.available() > 0)	// wait for input to engage debug mode
		{
			char_read = Serial.read();
			if (char_read != 0)
			{
				SF.userInterface();
			}
		}
		
		if (motorNext == true)
		{
			SF.motorControl();
		}
		
		if (sleepStatus == true)	// if sleepStatus is true, then run the sleep procedure
		{
			
			SF.sleepProcedure();
		}
	}
}


void loop(void) 
{
	// everything is handled in setup.
}


//	------------	FUNCTIONS	--------------------	//

void supportFunctions::userInterface(void)
{
	char char_read;
	boolean debugOnline = false;
	
	// stop timer1
	TCCR1A = 0;
	TCCR1B = 0;
	TCNT1  = 0;
	
	// Write out some instructions for the user.
	SF.helpMessage();
	
	debugOnline = true;
	while (debugOnline)
	{
		// read what the user wants to do.
		char_read = readNext();
		switch (char_read)
		{
			case '1':	// Read current time
			Serial.print("\nCurrent time is: ");
			showTime();
			Serial.print("\n\n");
			break;
			
			case '2':	// Change time
			Serial.println("\nPlease enter the time in the format yyyymmdd hhmmss dw");
			inputTime();
			Serial.print("Current time is ");
			showTime();
			Serial.print("\n\n");
			break;
			
			case '3':	// Change morning alarm
			RTC.readTime();	// get the time
			
			Serial.print("\nPlease enter the hour: ");	// we only have to change what is interesting
			RTC.h = i2dig(DEC);
			Serial.print("\nPlease enter the minutes: ");
			RTC.m = i2dig(DEC);
			
			RTC.writeAlarm1(DS3231_ALM_HMS);			// write setting to alarm
			
			Serial.print("\nAlarm set for ");			// echo out the settings
			showAlarm1();
			Serial.print("\n\n");
			break;
			
			case '4':	// Change morning alarm
			RTC.readTime();	// get the time
			
			Serial.print("\nPlease enter the hour: ");	// we only have to change what is interesting
			RTC.h = i2dig(DEC);
			Serial.print("\nPlease enter the minutes: ");
			RTC.m = i2dig(DEC);
			
			RTC.writeAlarm2(DS3231_ALM_HM);				// write setting to alarm
			
			Serial.print("\nAlarm set for ");			// echo out the settings
			showAlarm2();
			Serial.print("\n\n");
			break;
			
			case '0':	// Engage Advanced Debugging Mode
			usage();
			while (debugOnline)
			{
				Debug(&debugOnline);
			}
			
			// Write out some instructions for the user.
			SF.helpMessage();
			
			debugOnline = true;
			break;
			
			case 'e':	// Exit Debugging Mode and return to normal operation
			debugOnline = false;
			break;
			
			case 'h':
			// Write out some instructions for the user.
			SF.helpMessage();
			break;
			
			default:
			Serial.println("Command not recognized, try again");
			break;
		}
	}
	if (debugOnline == false)	// if user wants to exit , resume timer for standby
	{
		Serial.println("Resuming normal operation, priming alarms...");
		
		timer1_counter = 0;
		TCCR1B |= (1 << CS10)|(1 << CS12)|(1 << WGM12);
		TCNT1  = 0;
		
		Serial.println("The system will enter standby in 60 seconds unless interrupted");
		Serial.println("Send any command to engage Debugging Mode.");
		Serial.println();
		Serial.println();
	}
	if (Serial.available())		// flush the buffer
	{
		char_read = Serial.read();		// Dummy read, this result will be used for nothing.
	}
}


void supportFunctions::helpMessage(void)
{
	// Write out some instructions for the user.
	Serial.println("DebugMode engaged, you have the following options:");
	Serial.println("1 - Read current time");									// completed
	Serial.println("2 - Change time");											// completed
	Serial.println("3 - Change morning alarm");									// completed
	Serial.println("4 - Change evening alarm");									// completed
	Serial.print("\n");
	Serial.println("0 - Engage Advanced Debugging Mode");						// completed
	Serial.println("h - Show this help message");								// completed
	Serial.println("e - Exit Debugging Mode and return to normal operation");	// completed
	Serial.print("\n\n");
}


void supportFunctions::motorControl(void)	// Controls the motor
{
	motorNext = false;
}

void supportFunctions::sleepProcedure(void)	// puts microcontroller to sleep
{
	// stop timer1
	TCCR1A = 0;
	TCCR1B = 0;
	TCNT1  = 0;
	
	Serial.println("Engaging Standby Mode");
	delay(200);
	
	set_sleep_mode(SLEEP_MODE_PWR_DOWN);
	sleep_enable();
	sleep_mode();
	/** The program will continue from here. **/
	/* First thing to do is disable sleep. */
	sleep_disable();
	
	sleepStatus = false;
	Serial.println("Waking up");
	
	timer1_counter = 0;
	TCCR1B |= (1 << CS10)|(1 << CS12)|(1 << WGM12);
	TCNT1  = 0;
}


//	------------	INTERRUPTS	--------------------	//

ISR (INT0_vect)	// EXT_interrupt 0
{
	Serial.println("Interrupt entered");
	motorNext = true;
}

ISR (TIMER1_COMPA_vect)
{
	// timer1 overflow interrupt.
	if (timer1_counter == 10)	// remember to change this to 60!
	{
		// put microcontroller into powersaving mode
		timer1_counter = 0;
		sleepStatus = true;
	}
	else
	{
		timer1_counter++;
	}
}