/*
 * ArduinoCore.cpp
 *
 * Created: 30-03-2017 18:36:41
 * Author : Hans V. Rasmussen
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

