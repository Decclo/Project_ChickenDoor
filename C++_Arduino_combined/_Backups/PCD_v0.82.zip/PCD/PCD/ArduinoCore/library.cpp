/*
 * ArduinoCore.cpp
 *
 * Created: 13-06-2017 17:46:51
 * Author : Hans V. Rasmussen
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

